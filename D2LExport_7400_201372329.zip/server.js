/**
 * D2LValence package, js api.
 *
 * Copyright (c) 2012 Desire2Learn Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the license at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

/**
 * @fileOverview D2L API JS Library client
 * @author Adnan Duric <adnan.duric@desire2learn.com>
 */

function doAPIRequestResponse(host, port, appID, appKey, req, method, data)
{
	var appContext = new D2L.ApplicationContext('localhost', appID, appKey);

	var userId=document.getElementById('userIDField').value;
	var userKey=document.getElementById('userKeyField').value;

	var url;
	if(userId == '' || userKey == '') {
		//var userContext = appContext.createUserContext(host, port, window.location.href);
		var userContext = appContext.createUserContextWithValues(host, port, '', '');
		url = userContext.createUrlForAuthentication(req, method);
	} else {
		var userContext = appContext.createUserContextWithValues(host, port,userId,userKey);
		if(typeof userContext=="undefined"||typeof userContext.userId=="undefined"||userContext.userId=="") {
			return error(0, "Not authenticated");
		}
		url = userContext.createUrlForAuthentication(req, method);
	}
  var headers, contentType;
	switch(method) {
		case 'GET':
		case 'DELETE':
			break;
    case 'PUT':
    case 'POST':
		default:
      contentType = 'application/json';
      headers = {
        Accept: 'application/json',
        'Content-Type': 'application/json'
      };
	}
  $.ajax({
    type: method,
    url: url,
    contentType: contentType,
    headers: headers,
    success: function(data) {
		  var output;
		  if(data == "") return;
		    try {
			    if(typeof data === 'string') {
				    data = JSON.parse(data);
			    }
			      output = JSON.stringify(data, null, "\t");
		    } catch(e) {
			      output = 'Unexpected error, data: ' + data;
		    }
		    $('#responseField').val(output);
		    document.getElementById('responseField').hidden = false;
	  },
    error: function(jqXHR, textStatus, errorThrown) {
      console.log(jqXHR);
      console.log(textStatus);
      console.log(errorThrown);
		  $('#errorField').val("bad");
	  }
  });
}

function authenticateUserResponse(host, port, appID, appKey) {
	// create an app context
	var appContext = new D2L.ApplicationContext('localhost', appID, appKey);

	// create url
	var callback = window.location.href;
	var url = appContext.createUrlForAuthentication(host, port, callback);

	// go to login page and enter credentials
	window.location = url;
}

$(document).ready(function() {
	var appContext = new D2L.ApplicationContext('localhost', "", "");
	var userContext = appContext.createUserContext("valence.desire2learn.com", 443, window.location.href);
	if(typeof userContext=="undefined"||typeof userContext.userId=="undefined"||userContext.userId=="") {
		return;
	}
	// set the textboxes to show the user id and user key
	document.getElementById('userIDField').value = userContext.userId;
	document.getElementById('userKeyField').value = userContext.userKey;
});
