This sample shows how to authenticate with a Desire2Learn LMS, and make API calls.

To install it, unzip the contents in a folder that's in your web server's path and run index.php.